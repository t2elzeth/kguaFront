"""
    This is a sample backend service of your online shop.
    Here you can register and check the status of the payments initiated by your clients.
"""

import json
import requests
from flask import Flask, jsonify, request

""" This is your secret key. It's used for registering and checking payments. Please keep it in safe place."""
secret_key = 'YOUR_SECRET_KEY'

""" Stage/Test Ioka Processing URL"""
stage_ioka = "https://stage.ioka.kz"

app = Flask(__name__, static_url_path='', static_folder='.')


def calculate_amount(order_id: int) -> int:
    """ Here could be some queries to your database to get the total cost for the order """
    print(f'{order_id=}')
    return 100000


@app.route('/register/', methods=['POST'])
def register_payment():
    """
        1. Gets the order info from the store, e.g. order amount, currency, etc.
        2. Registers a payment on Ioka Processing.
        3. Returns the checkout info with payment form URL
    """
    order = json.loads(request.data)
    print(order)
    if 'id' not in order:
        return jsonify({'error': 'order id required'}), 400

    order_id = order['id']
    payload = {
        "amount": calculate_amount(order_id=order_id),
        "currency": 398,  # 398 for KZT
        "tr_type": 0,  # 0 for two-factor payment i.e. holding money and withdrawing them later, 1 for auto pay
        "order_id": order_id,
        "back_url": "http://localhost:8888/back.html",
        "callback_url": "http://localhost:8888/callback"
    }
    headers = {
        'Authorization': f'Bearer {secret_key}'
    }
    response = requests.post(url=f'{stage_ioka}/api/payments/register/', headers=headers, json=payload)
    checkout = response.json()
    print(checkout)
    return jsonify(checkout)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8888, debug=False)
